// ============================================
// DASHBOARD - User History
// ============================================

async function renderDashboard(container) {
  container.innerHTML = `
    <div class="page">
      <div class="section-header">
        <span class="section-title">📊 আমার ড্যাশবোর্ড</span>
      </div>
      <div id="myStats" style="margin-bottom:16px;"></div>
      <div style="display:flex;gap:8px;margin-bottom:14px;overflow-x:auto;padding-bottom:4px;">
        <button class="btn-primary btn-sm" onclick="loadDashTab('orders')" id="tab-orders">📦 অর্ডার</button>
        <button class="btn-secondary btn-sm" onclick="loadDashTab('borrows')" id="tab-borrows">📚 ধার</button>
        <button class="btn-secondary btn-sm" onclick="loadDashTab('mybooks')" id="tab-mybooks">🏡 আমার বই</button>
        <button class="btn-secondary btn-sm" onclick="loadDashTab('ebooks')" id="tab-ebooks">📖 আপলোড</button>
      </div>
      <div id="dashContent"></div>
    </div>
  `;
  loadMyStats();
  loadDashTab('orders');
}

async function loadMyStats() {
  const el = document.getElementById('myStats');
  if (!el) return;
  try {
    const [orders, borrows, myBooks, myEbooks] = await Promise.all([
      db.collection(ORDERS_COL).where('userPhone','==',currentUser.phone).get(),
      db.collection(BORROW_COL).where('borrowerPhone','==',currentUser.phone).get(),
      db.collection(PERSONAL_COL).where('ownerPhone','==',currentUser.phone).get(),
      db.collection(EBOOKS_COL).where('uploaderPhone','==',currentUser.phone).get()
    ]);
    el.innerHTML = `
      <div class="stats-row">
        <div class="stat-box"><div class="stat-num">${orders.size}</div><div class="stat-lbl">অর্ডার</div></div>
        <div class="stat-box"><div class="stat-num">${borrows.size}</div><div class="stat-lbl">ধার নিয়েছি</div></div>
        <div class="stat-box"><div class="stat-num">${myBooks.size}</div><div class="stat-lbl">আমার বই</div></div>
        <div class="stat-box"><div class="stat-num">${myEbooks.size}</div><div class="stat-lbl">আপলোড</div></div>
      </div>`;
  } catch(e){}
}

function loadDashTab(tab) {
  ['orders','borrows','mybooks','ebooks'].forEach(t => {
    const b = document.getElementById('tab-'+t);
    if (b) b.className = t===tab ? 'btn-primary btn-sm' : 'btn-secondary btn-sm';
  });
  switch(tab) {
    case 'orders':  loadMyOrders(); break;
    case 'borrows': loadMyBorrows(); break;
    case 'mybooks': loadMyPersonalBooks(); break;
    case 'ebooks':  loadMyEbooks(); break;
  }
}

async function loadMyOrders() {
  const el = document.getElementById('dashContent');
  if (!el) return;
  el.innerHTML = '<div class="text-muted text-sm">লোড হচ্ছে...</div>';
  try {
    const snap = await db.collection(ORDERS_COL).where('userPhone','==',currentUser.phone).orderBy('createdAt','desc').get();
    if (snap.empty) { el.innerHTML=`<div class="empty-state"><div class="empty-icon">📦</div><p>কোনো অর্ডার নেই</p></div>`; return; }
    el.innerHTML = snap.docs.map(d=>{
      const o=d.data();
      const badge=o.status==='confirmed'?'badge-green':o.status==='cancelled'?'badge-red':'badge-yellow';
      const label=o.status==='confirmed'?'নিশ্চিত':o.status==='cancelled'?'বাতিল':'অপেক্ষামান';
      return `<div class="history-item type-order">
        <div class="flex-between"><div class="history-title">${o.type==='print'?'🖨️':'📗'} ${o.bookTitle}</div><span class="badge ${badge}">${label}</span></div>
        <div class="history-date">📅 ${formatDate(o.createdAt)} · ${o.qty||1} কপি ${o.total?`· ৳${o.total}`:''}</div>
        ${o.type==='print'?`<div class="text-sm text-muted">ধরন: ${o.bindingType||''}</div>`:''}
      </div>`;
    }).join('');
  } catch(e){ el.innerHTML=`<div class="empty-state"><p>লোড করতে সমস্যা</p></div>`; }
}

async function loadMyBorrows() {
  const el = document.getElementById('dashContent');
  if (!el) return;
  el.innerHTML = '<div class="text-muted text-sm">লোড হচ্ছে...</div>';
  try {
    const snap = await db.collection(BORROW_COL).where('borrowerPhone','==',currentUser.phone).orderBy('createdAt','desc').get();
    if (snap.empty) { el.innerHTML=`<div class="empty-state"><div class="empty-icon">📚</div><p>কোনো ধারের রেকর্ড নেই</p></div>`; return; }
    el.innerHTML = snap.docs.map(d=>{
      const b=d.data();
      const badge=b.status==='returned'?'badge-green':b.status==='approved'?'badge-blue':b.status==='rejected'?'badge-red':'badge-yellow';
      const label=b.status==='returned'?'ফেরত':b.status==='approved'?'অনুমোদিত':b.status==='rejected'?'প্রত্যাখ্যাত':'অপেক্ষামান';
      return `<div class="history-item type-borrow">
        <div class="flex-between"><div class="history-title">📕 ${b.bookTitle}</div><span class="badge ${badge}">${label}</span></div>
        <div class="history-date">👤 মালিক: ${b.ownerName}</div>
        <div class="history-date">📅 ${b.fromDate} → ${b.toDate}</div>
        ${b.status==='approved'?`<a href="${buildWhatsAppLink(b.ownerPhone,`আমি "${b.bookTitle}" বইটি ফেরত দিতে চাই।`)}" target="_blank" class="btn-secondary btn-sm" style="text-decoration:none;display:inline-block;margin-top:6px;">📱 ফেরতের যোগাযোগ</a>`:''}
      </div>`;
    }).join('');
  } catch(e){ el.innerHTML=`<div class="empty-state"><p>লোড করতে সমস্যা</p></div>`; }
}

async function loadMyPersonalBooks() {
  const el = document.getElementById('dashContent');
  if (!el) return;
  el.innerHTML = '<div class="text-muted text-sm">লোড হচ্ছে...</div>';
  try {
    const snap = await db.collection(PERSONAL_COL).where('ownerPhone','==',currentUser.phone).orderBy('createdAt','desc').get();
    if (snap.empty) { el.innerHTML=`<div class="empty-state"><div class="empty-icon">🏡</div><p>আপনার কোনো বই নেই</p><button class="btn-primary btn-sm" onclick="navigate('personal')" style="margin-top:12px;">বই যোগ করুন</button></div>`; return; }
    el.innerHTML = snap.docs.map(d=>{
      const b=d.data();
      return `<div class="history-item">
        <div class="flex-between"><div class="history-title">📕 ${b.title}</div><span class="badge ${b.available!==false?'badge-green':'badge-red'}">${b.available!==false?'আছে':'ধার দেওয়া'}</span></div>
        ${b.author?`<div class="history-date">✍️ ${b.author}</div>`:''}
        <div class="history-date">📅 যোগ: ${formatDate(b.createdAt)}</div>
      </div>`;
    }).join('');
  } catch(e){ el.innerHTML=`<div class="empty-state"><p>লোড করতে সমস্যা</p></div>`; }
}

async function loadMyEbooks() {
  const el = document.getElementById('dashContent');
  if (!el) return;
  el.innerHTML = '<div class="text-muted text-sm">লোড হচ্ছে...</div>';
  try {
    const snap = await db.collection(EBOOKS_COL).where('uploaderPhone','==',currentUser.phone).orderBy('createdAt','desc').get();
    if (snap.empty) { el.innerHTML=`<div class="empty-state"><div class="empty-icon">📖</div><p>কোনো আপলোড নেই</p><button class="btn-primary btn-sm" onclick="navigate('ebook')" style="margin-top:12px;">বই আপলোড</button></div>`; return; }
    el.innerHTML = snap.docs.map(d=>{
      const b=d.data();
      return `<div class="history-item">
        <div class="history-title">📖 ${b.title}</div>
        ${b.author?`<div class="history-date">✍️ ${b.author}</div>`:''}
        <div class="history-date">📅 ${formatDate(b.createdAt)}</div>
        <div style="display:flex;gap:6px;margin-top:6px;">
          <a href="${b.driveLink}" target="_blank" class="btn-secondary btn-sm" style="text-decoration:none;display:inline-block;">🔗 লিংক</a>
          <button class="btn-danger btn-sm" onclick="deleteMyEbook('${d.id}')">🗑️</button>
        </div>
      </div>`;
    }).join('');
  } catch(e){ el.innerHTML=`<div class="empty-state"><p>লোড করতে সমস্যা</p></div>`; }
}

async function deleteMyEbook(id) {
  if (!confirm('এই ই-বুক মুছে ফেলবেন?')) return;
  try { await db.collection(EBOOKS_COL).doc(id).delete(); showToast('মুছে ফেলা হয়েছে'); loadMyEbooks(); }
  catch(e){ showToast('সমস্যা হয়েছে'); }
}

// ============================================
// ADMIN PANEL
// ============================================

let adminAuthenticated = false;
let adminSettings = null;

async function renderAdmin(container) {
  if (!adminAuthenticated) { showAdminLogin(container); return; }
  showAdminPanel(container);
}

function showAdminLogin(container) {
  container.innerHTML = `
    <div class="page">
      <div class="card" style="max-width:400px;margin:40px auto;">
        <div style="background:var(--primary-dark);color:#fff;border-radius:var(--radius) var(--radius) 0 0;margin:-16px -16px 16px;padding:20px;text-align:center;font-family:var(--font-serif);font-size:18px;font-weight:700;">
          🔐 অ্যাডমিন লগইন
        </div>
        <div class="input-group">
          <label>অ্যাডমিন পাসওয়ার্ড</label>
          <input type="password" id="adminPassInput" placeholder="পাসওয়ার্ড দিন" onkeydown="if(event.key==='Enter')checkAdminPass()">
        </div>
        <button class="btn-primary" onclick="checkAdminPass()">প্রবেশ করুন</button>
      </div>
    </div>`;
}

async function checkAdminPass() {
  const pass = document.getElementById('adminPassInput').value;
  const settings = await getSettings();
  if (pass === (settings.adminPass || 'admin123')) {
    adminAuthenticated = true;
    adminSettings = settings;
    showAdminPanel(document.getElementById('mainContent'));
  } else {
    showToast('❌ ভুল পাসওয়ার্ড');
  }
}

async function showAdminPanel(container) {
  adminSettings = await getSettings();
  container.innerHTML = `
    <div class="page">
      <div style="background:var(--primary-dark);color:#fff;border-radius:var(--radius);margin-bottom:16px;padding:16px;text-align:center;font-family:var(--font-serif);font-size:18px;font-weight:700;">
        ⚙️ অ্যাডমিন প্যানেল
      </div>

      <div class="card" style="margin-bottom:16px;">
        <div style="font-size:14px;font-weight:700;color:var(--primary-dark);margin-bottom:10px;text-transform:uppercase;letter-spacing:0.5px;">⚙️ সেটিংস</div>
        <div class="input-group">
          <label>WhatsApp নম্বর (অর্ডার আসবে এখানে)</label>
          <input type="tel" id="setWA" value="${adminSettings.whatsapp||''}" placeholder="01XXXXXXXXX">
        </div>
        <div class="input-group">
          <label>Facebook পেইজ Username</label>
          <input type="text" id="setFB" value="${adminSettings.fbPage||''}" placeholder="yourpage">
        </div>
        <div class="input-group">
          <label>অ্যাডমিন পাসওয়ার্ড পরিবর্তন</label>
          <input type="password" id="setPass" placeholder="নতুন পাসওয়ার্ড (খালি রাখলে পরিবর্তন হবে না)">
        </div>
        <div class="input-group">
          <label>অ্যাডমিন ফোন নম্বর</label>
          <input type="tel" id="setAdminPhone" value="${adminSettings.adminPhone||''}" placeholder="01XXXXXXXXX">
        </div>
        <button class="btn-primary" onclick="saveSettings()">সেটিংস সেভ করুন</button>
      </div>

      <div style="display:flex;gap:8px;margin-bottom:14px;overflow-x:auto;padding-bottom:4px;">
        <button class="btn-primary btn-sm" onclick="loadAdminTab('orders')" id="atab-orders">📦 অর্ডার</button>
        <button class="btn-secondary btn-sm" onclick="loadAdminTab('borrows')" id="atab-borrows">📚 ধার</button>
        <button class="btn-secondary btn-sm" onclick="loadAdminTab('users')" id="atab-users">👥 ইউজার</button>
        <button class="btn-secondary btn-sm" onclick="loadAdminTab('ebooks')" id="atab-ebooks">📖 ই-বুক</button>
        <button class="btn-secondary btn-sm" onclick="loadAdminTab('booklist')" id="atab-booklist">🛒 তালিকা</button>
      </div>
      <div id="adminContent"></div>
    </div>`;
  loadAdminTab('orders');
}

function loadAdminTab(tab) {
  ['orders','borrows','users','ebooks','booklist'].forEach(t=>{
    const b=document.getElementById('atab-'+t);
    if(b) b.className=t===tab?'btn-primary btn-sm':'btn-secondary btn-sm';
  });
  switch(tab){
    case 'orders':   loadAdminOrders(); break;
    case 'borrows':  loadAdminBorrows(); break;
    case 'users':    loadAdminUsers(); break;
    case 'ebooks':   loadAdminEbooks(); break;
    case 'booklist': loadAdminBooklist(); break;
  }
}

async function saveSettings() {
  const wa=document.getElementById('setWA').value.trim();
  const fb=document.getElementById('setFB').value.trim();
  const pass=document.getElementById('setPass').value.trim();
  const adminPhone=document.getElementById('setAdminPhone').value.trim();
  const update={whatsapp:wa,fbPage:fb,adminPhone};
  if(pass) update.adminPass=pass;
  try {
    await db.collection(SETTINGS_COL).doc('config').set(update,{merge:true});
    adminSettings={...adminSettings,...update};
    // Set admin role
    if(adminPhone) await db.collection(USERS_COL).doc(adminPhone).update({role:'admin'}).catch(()=>{});
    showToast('✅ সেটিংস সেভ হয়েছে!');
  } catch(e){ showToast('সমস্যা হয়েছে'); }
}

async function loadAdminOrders() {
  const el=document.getElementById('adminContent');
  if(!el) return;
  el.innerHTML='<div class="text-muted text-sm">লোড হচ্ছে...</div>';
  try {
    const snap=await db.collection(ORDERS_COL).orderBy('createdAt','desc').limit(50).get();
    if(snap.empty){el.innerHTML=`<div class="empty-state"><p>কোনো অর্ডার নেই</p></div>`;return;}
    el.innerHTML=snap.docs.map(d=>{
      const o=d.data();
      const badge=o.status==='confirmed'?'badge-green':o.status==='cancelled'?'badge-red':'badge-yellow';
      const label=o.status==='confirmed'?'নিশ্চিত':o.status==='cancelled'?'বাতিল':'অপেক্ষামান';
      return `<div class="history-item type-order">
        <div class="flex-between"><div class="history-title">${o.type==='print'?'🖨️':'📗'} ${o.bookTitle}</div><span class="badge ${badge}">${label}</span></div>
        <div class="history-date">👤 ${o.userName} · 📞 ${o.userPhone}</div>
        <div class="history-date">📅 ${formatDate(o.createdAt)} · ${o.qty||1} কপি ${o.total?`· ৳${o.total}`:''}</div>
        ${o.address?`<div class="history-date">📍 ${o.address}</div>`:''}
        ${o.status==='pending'?`<div style="display:flex;gap:6px;margin-top:8px;">
          <button class="btn-primary btn-sm" onclick="updateOrderStatus('${d.id}','confirmed')">✅ নিশ্চিত</button>
          <button class="btn-danger btn-sm" onclick="updateOrderStatus('${d.id}','cancelled')">❌ বাতিল</button>
          <a href="${buildWhatsAppLink(o.userPhone,`আপনার "${o.bookTitle}" বইয়ের অর্ডার নিশ্চিত হয়েছে। ধন্যবাদ!`)}" target="_blank" class="btn-secondary btn-sm" style="text-decoration:none;display:inline-block;">📱 নোটিফাই</a>
        </div>`:''}
      </div>`;
    }).join('');
  } catch(e){el.innerHTML=`<div class="empty-state"><p>লোড করতে সমস্যা</p></div>`;}
}

async function updateOrderStatus(orderId,status) {
  try{ await db.collection(ORDERS_COL).doc(orderId).update({status}); showToast('✅ আপডেট হয়েছে'); loadAdminOrders(); }
  catch(e){ showToast('সমস্যা হয়েছে'); }
}

async function loadAdminBorrows() {
  const el=document.getElementById('adminContent');
  if(!el) return;
  el.innerHTML='<div class="text-muted text-sm">লোড হচ্ছে...</div>';
  try {
    const snap=await db.collection(BORROW_COL).orderBy('createdAt','desc').limit(50).get();
    if(snap.empty){el.innerHTML=`<div class="empty-state"><p>কোনো রেকর্ড নেই</p></div>`;return;}
    el.innerHTML=snap.docs.map(d=>{
      const b=d.data();
      const badge=b.status==='returned'?'badge-green':b.status==='approved'?'badge-blue':b.status==='rejected'?'badge-red':'badge-yellow';
      const label=b.status==='returned'?'ফেরত':b.status==='approved'?'ধার দেওয়া':b.status==='rejected'?'না':'অনুরোধ';
      return `<div class="history-item type-borrow">
        <div class="flex-between"><div class="history-title">📕 ${b.bookTitle}</div><span class="badge ${badge}">${label}</span></div>
        <div class="history-date">🔵 ${b.borrowerName} (${b.borrowerPhone})</div>
        <div class="history-date">🟢 মালিক: ${b.ownerName} (${b.ownerPhone})</div>
        <div class="history-date">📅 ${b.fromDate} → ${b.toDate}</div>
      </div>`;
    }).join('');
  } catch(e){el.innerHTML=`<div class="empty-state"><p>লোড করতে সমস্যা</p></div>`;}
}

async function loadAdminUsers() {
  const el=document.getElementById('adminContent');
  if(!el) return;
  el.innerHTML='<div class="text-muted text-sm">লোড হচ্ছে...</div>';
  try {
    const snap=await db.collection(USERS_COL).orderBy('createdAt','desc').get();
    if(snap.empty){el.innerHTML=`<div class="empty-state"><p>কোনো ইউজার নেই</p></div>`;return;}
    el.innerHTML=`<div class="text-sm text-muted" style="margin-bottom:10px;">মোট: ${snap.size} জন</div>`+
    snap.docs.map(d=>{
      const u=d.data();
      return `<div class="history-item">
        <div class="flex-between"><div class="history-title">👤 ${u.name}</div>${u.role==='admin'?`<span class="badge badge-blue">অ্যাডমিন</span>`:''}</div>
        <div class="history-date">📞 ${u.phone}</div>
        <div class="history-date">📍 ${u.village||''}, ${u.upazila||''}, ${u.district||''}</div>
        <div class="history-date">📅 যোগ: ${formatDate(u.createdAt)}</div>
      </div>`;
    }).join('');
  } catch(e){el.innerHTML=`<div class="empty-state"><p>লোড করতে সমস্যা</p></div>`;}
}

async function loadAdminEbooks() {
  const el=document.getElementById('adminContent');
  if(!el) return;
  el.innerHTML='<div class="text-muted text-sm">লোড হচ্ছে...</div>';
  try {
    const snap=await db.collection(EBOOKS_COL).orderBy('createdAt','desc').get();
    if(snap.empty){el.innerHTML=`<div class="empty-state"><p>কোনো ই-বুক নেই</p></div>`;return;}
    el.innerHTML=snap.docs.map(d=>{
      const b=d.data();
      return `<div class="history-item">
        <div class="flex-between"><div class="history-title">📖 ${b.title}</div><button class="btn-danger btn-sm" onclick="adminDeleteDoc('${EBOOKS_COL}','${d.id}','ebooks')">🗑️</button></div>
        <div class="history-date">✍️ ${b.author||'অজানা'} · 👤 ${b.uploaderName}</div>
        <div class="history-date">📅 ${formatDate(b.createdAt)}</div>
      </div>`;
    }).join('');
  } catch(e){el.innerHTML=`<div class="empty-state"><p>লোড করতে সমস্যা</p></div>`;}
}

async function loadAdminBooklist() {
  const el=document.getElementById('adminContent');
  if(!el) return;
  el.innerHTML='<div class="text-muted text-sm">লোড হচ্ছে...</div>';
  try {
    const snap=await db.collection(BOOKLIST_COL).orderBy('createdAt','desc').get();
    if(snap.empty){el.innerHTML=`<div class="empty-state"><p>কোনো বই নেই</p></div>`;return;}
    el.innerHTML=snap.docs.map(d=>{
      const b=d.data();
      return `<div class="history-item">
        <div class="flex-between"><div class="history-title">📗 ${b.title}</div><button class="btn-danger btn-sm" onclick="adminDeleteDoc('${BOOKLIST_COL}','${d.id}','booklist')">🗑️</button></div>
        <div class="history-date">${b.author?`✍️ ${b.author}`:''}${b.price?` · ৳${b.price}`:''}</div>
      </div>`;
    }).join('');
  } catch(e){el.innerHTML=`<div class="empty-state"><p>লোড করতে সমস্যা</p></div>`;}
}

async function adminDeleteDoc(col,id,tab) {
  if(!confirm('মুছে ফেলবেন?')) return;
  try{ await db.collection(col).doc(id).delete(); showToast('মুছে ফেলা হয়েছে'); loadAdminTab(tab); }
  catch(e){ showToast('সমস্যা হয়েছে'); }
}
